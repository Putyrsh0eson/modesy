'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { vendorService } from '@/services/vendorService';
import {
  Package,
  DollarSign,
  Image as ImageIcon,
  Sliders,
  Truck,
  CheckCircle,
  ArrowRight,
  ArrowLeft
} from 'lucide-react';

export default function VendorAddProductPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<'details' | 'pricing' | 'images' | 'variations' | 'shipping'>('details');

  // Form State
  const [formData, setFormData] = useState({
    title: '',
    category: 'Women / Clothing',
    description: '',
    tags: 'fashion, summer, trendy',
    price: 49.99,
    discountRate: 0,
    sku: 'MDS-589210',
    stock: 20,
    image: '/sites/modesy/banner-clothing.jpg',
    shippingCost: 0,
    hasVariations: true,
    colors: 'Black, White, Floral Blue',
    sizes: 'S, M, L, XL'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await vendorService.addProduct({
      title: formData.title || 'Demo Added Item',
      category: formData.category,
      price: Number(formData.price),
      discountRate: Number(formData.discountRate),
      stock: Number(formData.stock),
      image: formData.image
    });
    setIsSubmitting(false);
    setSuccess(true);
    setTimeout(() => {
      router.push('/dashboard/products');
    }, 1500);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-white p-5 rounded-lg border border-[#e6e8eb] shadow-sm">
        <h1 className="text-xl font-bold text-gray-800">Add New Product</h1>
        <p className="text-xs text-gray-500 mt-0.5">Fill in the required information to publish a new listing to Modesy marketplace</p>
      </div>

      {success && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-emerald-800 text-xs font-semibold">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          Product created successfully! Redirecting to products list...
        </div>
      )}

      {/* Tabs Bar */}
      <div className="bg-white rounded-lg border border-[#e6e8eb] shadow-sm overflow-hidden">
        <div className="flex border-b border-gray-200 bg-[#f8f9fa] overflow-x-auto">
          {[
            { id: 'details', label: '1. Basic Details', icon: Package },
            { id: 'pricing', label: '2. Pricing & Stock', icon: DollarSign },
            { id: 'images', label: '3. Product Images', icon: ImageIcon },
            { id: 'variations', label: '4. Variations', icon: Sliders },
            { id: 'shipping', label: '5. Shipping', icon: Truck },
          ].map(tab => {
            const Icon = tab.icon;
            const isCurrent = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
                  isCurrent
                    ? 'border-[#222d32] text-[#222d32] bg-white'
                    : 'border-transparent text-gray-500 hover:text-gray-800 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* TAB 1: BASIC DETAILS */}
          {activeTab === 'details' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Product Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Floral Women Summer Sundress"
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Category <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="Women / Clothing">Women / Clothing</option>
                    <option value="Women / Shoes">Women / Shoes</option>
                    <option value="Men / Fashion">Men / Fashion</option>
                    <option value="Electronics / Audio">Electronics / Audio</option>
                    <option value="Jewelry & Watches">Jewelry & Watches</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Tags (Comma separated)
                  </label>
                  <input
                    type="text"
                    value={formData.tags}
                    onChange={e => setFormData({ ...formData, tags: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Product Description
                </label>
                <textarea
                  rows={4}
                  placeholder="Describe your product materials, fit, care instructions..."
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                ></textarea>
              </div>

              <div className="flex justify-end pt-4">
                <button
                  type="button"
                  onClick={() => setActiveTab('pricing')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#222d32] text-white text-xs font-semibold rounded-md"
                >
                  <span>Next: Pricing & Stock</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: PRICING & STOCK */}
          {activeTab === 'pricing' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Regular Price ($ USD) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formData.price}
                    onChange={e => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Discount Rate (%)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="99"
                    value={formData.discountRate}
                    onChange={e => setFormData({ ...formData, discountRate: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    SKU (Stock Keeping Unit)
                  </label>
                  <input
                    type="text"
                    value={formData.sku}
                    onChange={e => setFormData({ ...formData, sku: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Initial Stock Quantity <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.stock}
                    onChange={e => setFormData({ ...formData, stock: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setActiveTab('details')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 border border-gray-300 text-gray-700 text-xs font-semibold rounded-md"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('images')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#222d32] text-white text-xs font-semibold rounded-md"
                >
                  <span>Next: Product Images</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: IMAGES */}
          {activeTab === 'images' && (
            <div className="space-y-4">
              <label className="block text-xs font-semibold text-gray-700">
                Upload Product Images (JPG, PNG, WebP)
              </label>

              <div className="border-2 border-dashed border-gray-300 hover:border-indigo-500 p-8 rounded-lg text-center cursor-pointer transition-colors bg-gray-50">
                <ImageIcon className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                <p className="text-xs font-semibold text-gray-700">Drag and drop images here, or browse files</p>
                <p className="text-[11px] text-gray-500 mt-1">Recommended size: 800x800 px. Max file size: 5MB</p>
              </div>

              <div className="grid grid-cols-4 gap-3">
                <div className="border border-gray-200 rounded p-1 text-center bg-white">
                  <div className="h-20 bg-gray-100 rounded flex items-center justify-center text-xs text-gray-400">
                    Main Photo
                  </div>
                  <span className="text-[10px] text-emerald-600 font-semibold block mt-1">Featured</span>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setActiveTab('pricing')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 border border-gray-300 text-gray-700 text-xs font-semibold rounded-md"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('variations')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#222d32] text-white text-xs font-semibold rounded-md"
                >
                  <span>Next: Variations</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: VARIATIONS */}
          {activeTab === 'variations' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Color Options (Comma separated)
                </label>
                <input
                  type="text"
                  value={formData.colors}
                  onChange={e => setFormData({ ...formData, colors: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Size Options (Comma separated)
                </label>
                <input
                  type="text"
                  value={formData.sizes}
                  onChange={e => setFormData({ ...formData, sizes: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setActiveTab('images')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 border border-gray-300 text-gray-700 text-xs font-semibold rounded-md"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('shipping')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#222d32] text-white text-xs font-semibold rounded-md"
                >
                  <span>Next: Shipping Options</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 5: SHIPPING & PUBLISH */}
          {activeTab === 'shipping' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Shipping Cost ($ USD)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.shippingCost}
                  onChange={e => setFormData({ ...formData, shippingCost: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                />
                <span className="text-[11px] text-gray-500 mt-1 block">Set 0 for Free Shipping</span>
              </div>

              <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                <p className="text-xs font-semibold text-gray-800">Ready to Publish?</p>
                <p className="text-[11px] text-gray-500 mt-0.5">
                  Your product will be submitted and queued for marketplace review.
                </p>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setActiveTab('variations')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 border border-gray-300 text-gray-700 text-xs font-semibold rounded-md"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#28a745] hover:bg-[#218838] text-white text-xs font-bold rounded-md shadow transition-colors"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>{isSubmitting ? 'Publishing...' : 'Save & Publish Product'}</span>
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
