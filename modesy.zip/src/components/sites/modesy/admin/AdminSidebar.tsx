'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import {
  Home,
  Palette,
  Sliders,
  Layers,
  ShoppingCart,
  ShoppingBag,
  Flag,
  Package,
  Folder,
  Tag,
  Asterisk,
  SlidersHorizontal,
  CreditCard,
  Coins,
  Wallet,
  FileText,
  Newspaper,
  MapPin,
  Users,
  ShieldCheck,
  Settings,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onCloseMobile?: () => void;
}

export function AdminSidebar({ isOpen, onCloseMobile }: SidebarProps) {
  const pathname = usePathname();

  // State to manage open/collapsed submenus
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    orders: pathname.includes('/admin/orders') || pathname.includes('/admin/transactions'),
    products: pathname.includes('/admin/products'),
    payments: pathname.includes('/admin/payments') || pathname.includes('/admin/earnings'),
    content: pathname.includes('/admin/pages') || pathname.includes('/admin/blog'),
  });

  const toggleSection = (key: string) => {
    setOpenSections((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const isLinkActive = (path: string) => pathname === path;

  return (
    <aside
      className={`fixed top-0 left-0 bottom-0 z-50 bg-[#222d32] text-[#b8c7ce] w-[230px] flex flex-col transition-transform duration-300 shadow-lg ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      }`}
    >
      {/* Brand Header */}
      <div className="h-[50px] bg-[#1a2226] flex items-center px-4 border-b border-[#1e282c] shrink-0">
        <Link href="/admin" className="flex items-center gap-1.5 text-white font-sans">
          <span className="text-[17px] font-bold tracking-tight">Modesy</span>
          <span className="text-[17px] font-normal text-gray-300">Panel</span>
        </Link>
      </div>

      {/* User Status Profile */}
      <div className="p-3.5 flex items-center gap-3 border-b border-[#1e282c] shrink-0 bg-[#222d32]">
        <div className="w-[42px] h-[42px] rounded-full overflow-hidden relative border border-[#3b4c56] shrink-0 bg-[#34495e]">
          <Image
            src="/sites/modesy/avatar-admin.jpg"
            alt="Admin"
            fill
            className="object-cover"
            onError={(e) => {
              // fallback if image not found
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
        </div>
        <div className="flex flex-col">
          <span className="text-[13.5px] font-bold text-white leading-tight">Admin</span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="w-2 h-2 rounded-full bg-[#00a65a]" />
            <span className="text-[11px] text-[#8aa4af]">Online</span>
          </div>
        </div>
      </div>

      {/* Navigation Menu List */}
      <div className="flex-1 overflow-y-auto no-scrollbar py-2 text-[13px] select-none font-sans">
        {/* NAVIGATION SECTION */}
        <div className="px-4 py-1.5 text-[10px] font-bold uppercase tracking-wider text-[#4b646f]">
          Navigation
        </div>

        <Link
          href="/admin"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Home className="w-4 h-4 text-[#8aa4af]" />
          <span>Home</span>
        </Link>

        <Link
          href="/admin/theme"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/theme')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Palette className="w-4 h-4 text-[#8aa4af]" />
          <span>Theme</span>
        </Link>

        <Link
          href="/admin/slider"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/slider')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Sliders className="w-4 h-4 text-[#8aa4af]" />
          <span>Slider</span>
        </Link>

        <Link
          href="/admin/homepage-manager"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/homepage-manager')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Layers className="w-4 h-4 text-[#8aa4af]" />
          <span>Homepage Manager</span>
        </Link>

        {/* ORDERS SECTION */}
        <div className="px-4 pt-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-[#4b646f]">
          Orders
        </div>

        {/* Orders Dropdown */}
        <div>
          <button
            type="button"
            onClick={() => toggleSection('orders')}
            className={`w-full flex items-center justify-between px-4 py-2.5 transition-colors border-l-[3px] ${
              pathname.includes('/admin/orders') || pathname.includes('/admin/transactions')
                ? 'bg-[#1e282c] text-white border-[#00a99d]'
                : 'border-transparent hover:bg-[#1e282c] hover:text-white'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <ShoppingCart className="w-4 h-4 text-[#8aa4af]" />
              <span>Orders</span>
            </div>
            {openSections.orders ? (
              <ChevronDown className="w-3.5 h-3.5 text-[#8aa4af]" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5 text-[#8aa4af]" />
            )}
          </button>

          {openSections.orders && (
            <div className="bg-[#2c3b41] py-1 text-[12.5px]">
              <Link
                href="/admin/orders"
                className={`block pl-10 pr-4 py-2 transition-colors ${
                  isLinkActive('/admin/orders')
                    ? 'text-white font-semibold'
                    : 'text-[#8aa4af] hover:text-white'
                }`}
              >
                Orders
              </Link>
              <Link
                href="/admin/transactions"
                className={`block pl-10 pr-4 py-2 transition-colors ${
                  isLinkActive('/admin/transactions')
                    ? 'text-white font-semibold'
                    : 'text-[#8aa4af] hover:text-white'
                }`}
              >
                Transactions
              </Link>
            </div>
          )}
        </div>

        <Link
          href="/admin/digital-sales"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/digital-sales')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <ShoppingBag className="w-4 h-4 text-[#8aa4af]" />
          <span>Digital Sales</span>
        </Link>

        <Link
          href="/admin/refund-requests"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/refund-requests')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Flag className="w-4 h-4 text-[#8aa4af]" />
          <span>Refund Requests</span>
        </Link>

        {/* PRODUCTS SECTION */}
        <div className="px-4 pt-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-[#4b646f]">
          Products
        </div>

        <Link
          href="/admin/products"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/products')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Package className="w-4 h-4 text-[#8aa4af]" />
          <span>Products</span>
        </Link>

        <Link
          href="/admin/quote-requests"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/quote-requests')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Tag className="w-4 h-4 text-[#8aa4af]" />
          <span>Quote Requests</span>
        </Link>

        <Link
          href="/admin/categories"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/categories')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Folder className="w-4 h-4 text-[#8aa4af]" />
          <span>Categories</span>
        </Link>

        <Link
          href="/admin/tags"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/tags')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Tag className="w-4 h-4 text-[#8aa4af]" />
          <span>Tags</span>
        </Link>

        <Link
          href="/admin/brands"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/brands')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Asterisk className="w-4 h-4 text-[#8aa4af]" />
          <span>Brands</span>
        </Link>

        <Link
          href="/admin/custom-fields"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/custom-fields')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4 text-[#8aa4af]" />
          <span>Custom Fields</span>
        </Link>

        {/* PAYMENTS SECTION */}
        <div className="px-4 pt-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-[#4b646f]">
          Payments
        </div>

        <Link
          href="/admin/payments"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/payments')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <CreditCard className="w-4 h-4 text-[#8aa4af]" />
          <span>Payments</span>
        </Link>

        <Link
          href="/admin/earnings"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/earnings')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Coins className="w-4 h-4 text-[#8aa4af]" />
          <span>Earnings</span>
        </Link>

        <Link
          href="/admin/payouts"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/payouts')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Wallet className="w-4 h-4 text-[#8aa4af]" />
          <span>Payouts</span>
        </Link>

        {/* CONTENT SECTION */}
        <div className="px-4 pt-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-[#4b646f]">
          Content
        </div>

        <Link
          href="/admin/pages"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/pages')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <FileText className="w-4 h-4 text-[#8aa4af]" />
          <span>Pages</span>
        </Link>

        <Link
          href="/admin/blog"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/blog')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Newspaper className="w-4 h-4 text-[#8aa4af]" />
          <span>Blog</span>
        </Link>

        <Link
          href="/admin/location"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/location')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <MapPin className="w-4 h-4 text-[#8aa4af]" />
          <span>Location</span>
        </Link>

        {/* MEMBERSHIP SECTION */}
        <div className="px-4 pt-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-[#4b646f]">
          Membership
        </div>

        <Link
          href="/admin/users"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/users')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Users className="w-4 h-4 text-[#8aa4af]" />
          <span>Users</span>
        </Link>

        <Link
          href="/admin/roles-permissions"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/roles-permissions')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-[#8aa4af]" />
          <span>Roles & Permissions</span>
        </Link>

        {/* SETTINGS SECTION */}
        <div className="px-4 pt-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-[#4b646f]">
          Settings
        </div>

        <Link
          href="/admin/settings"
          className={`flex items-center gap-2.5 px-4 py-2.5 transition-colors border-l-[3px] ${
            isLinkActive('/admin/settings')
              ? 'bg-[#1e282c] text-white border-[#00a99d]'
              : 'border-transparent hover:bg-[#1e282c] hover:text-white'
          }`}
        >
          <Settings className="w-4 h-4 text-[#8aa4af]" />
          <span>General Settings</span>
        </Link>

        <div className="h-8" />
      </div>
    </aside>
  );
}
