'use client';

import React, { createContext, useContext, useState } from 'react';
import { Product, CurrencyOption, LanguageOption, AuthUser } from '@/types/modesy';
import { CURRENCIES, LANGUAGES } from '@/data/modesy-mock';

interface CartItem {
  product: Product;
  quantity: number;
}

export const PRESET_USERS: Record<string, AuthUser> = {
  admin: {
    id: '1',
    username: 'Admin',
    email: 'admin@modesy.com',
    role: 'admin',
    avatar: '/sites/modesy/avatar-admin.jpg',
    slug: 'admin',
  },
  moderator: {
    id: '2',
    username: 'Moderator',
    email: 'moderator@modesy.com',
    role: 'moderator',
    avatar: '/sites/modesy/avatar-admin.jpg',
    slug: 'moderator',
  },
  vendor: {
    id: '3',
    username: 'Trendshop',
    email: 'vendor@modesy.com',
    role: 'vendor',
    avatar: '/sites/modesy/avatar-vendor.jpg',
    slug: 'trendshop',
  },
  member: {
    id: '4',
    username: 'Peter Jone',
    email: 'member@modesy.com',
    role: 'member',
    avatar: '/sites/modesy/avatar-admin.jpg',
    slug: 'peter-jone',
  },
  saadan: {
    id: '5',
    username: 'Saadan',
    email: 'saadan@codingest.net',
    role: 'member',
    avatar: '/sites/modesy/avatar-admin.jpg',
    slug: 'saadan',
  }
};

export function hasAdminPanelAccess(user: AuthUser | null | undefined): boolean {
  if (!user) return false;
  return user.role === 'admin' || user.role === 'moderator';
}

export function isVendorRole(user: AuthUser | null | undefined): boolean {
  if (!user) return false;
  return user.role === 'vendor' || user.role === 'admin';
}

interface ModesyContextType {
  cartItems: CartItem[];
  cartCount: number;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string | number) => void;
  wishlistIds: (string | number)[];
  toggleWishlist: (productId: string | number) => void;
  currency: CurrencyOption;
  setCurrency: (c: CurrencyOption) => void;
  language: LanguageOption;
  setLanguage: (l: LanguageOption) => void;
  isLocationModalOpen: boolean;
  setLocationModalOpen: (open: boolean) => void;
  isLoginModalOpen: boolean;
  setLoginModalOpen: (open: boolean) => void;
  cartModalProduct: Product | null;
  setCartModalProduct: (p: Product | null) => void;
  isMobileDrawerOpen: boolean;
  setMobileDrawerOpen: (open: boolean) => void;
  user: AuthUser | null;
  login: (user: AuthUser) => void;
  logout: () => void;
  hasAdminAccess: boolean;
  isVendor: boolean;
}

const ModesyContext = createContext<ModesyContextType | undefined>(undefined);

export function ModesyProvider({ children }: { children: React.ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [wishlistIds, setWishlistIds] = useState<(string | number)[]>([]);
  const [currency, setCurrency] = useState<CurrencyOption>(CURRENCIES[0]);
  const [language, setLanguage] = useState<LanguageOption>(LANGUAGES[0]);
  const [isLocationModalOpen, setLocationModalOpen] = useState(false);
  const [isLoginModalOpen, setLoginModalOpen] = useState(false);
  const [cartModalProduct, setCartModalProduct] = useState<Product | null>(null);
  const [isMobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [user, setUser] = useState<AuthUser | null>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('modesy_user');
        if (saved) return JSON.parse(saved);
      } catch {
        // ignore
      }
    }
    return PRESET_USERS.admin;
  });

  const login = (u: AuthUser) => {
    setUser(u);
    try {
      localStorage.setItem('modesy_user', JSON.stringify(u));
    } catch {
      // ignore
    }
  };

  const logout = () => {
    setUser(null);
    try {
      localStorage.removeItem('modesy_user');
    } catch {
      // ignore
    }
  };

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const addToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setCartModalProduct(product);
  };

  const removeFromCart = (productId: string | number) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const toggleWishlist = (productId: string | number) => {
    setWishlistIds((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  return (
    <ModesyContext.Provider
      value={{
        cartItems,
        cartCount,
        addToCart,
        removeFromCart,
        wishlistIds,
        toggleWishlist,
        currency,
        setCurrency,
        language,
        setLanguage,
        isLocationModalOpen,
        setLocationModalOpen,
        isLoginModalOpen,
        setLoginModalOpen,
        cartModalProduct,
        setCartModalProduct,
        isMobileDrawerOpen,
        setMobileDrawerOpen,
        user,
        login,
        logout,
        hasAdminAccess: hasAdminPanelAccess(user),
        isVendor: isVendorRole(user),
      }}
    >
      {children}
    </ModesyContext.Provider>
  );
}

export function useModesy() {
  const context = useContext(ModesyContext);
  if (!context) {
    throw new Error('useModesy must be used within a ModesyProvider');
  }
  return context;
}
