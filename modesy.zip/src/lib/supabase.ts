import { ALL_PRODUCTS } from '@/data/modesy-mock';
import { Product, Order } from '@/types/modesy';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  !supabaseUrl.includes('your-project-id')
);

// Client instance - only initialized if environment variables are present
export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

import { marketplaceStore } from '@/services/marketplaceStore';

// Product queries
export async function getAllProducts(): Promise<Product[]> {
  if (isSupabaseConfigured && supabase) {
    try {
      const { data, error } = await supabase.from('products').select('*');
      if (!error && data && data.length > 0) {
        return marketplaceStore.getProducts();
      }
    } catch {
      // fallback
    }
  }
  return marketplaceStore.getProducts();
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const found = marketplaceStore.getProductBySlug(slug);
  if (found) return found;
  const products = await getAllProducts();
  const product = products.find((p) => p.slug === slug);
  return product || null;
}

// Order & checkout mutations
export async function submitOrder(orderData: {
  total?: number;
  paymentMethod?: string;
  items?: Order['items'];
  subtotal?: number;
  shipping?: number;
  tax?: number;
  currency?: string;
  customer?: Order['customer'];
  status?: string;
}): Promise<Order> {
  const customer = orderData.customer || {
    fullName: 'Customer',
    email: 'customer@example.com',
    phone: '+1 234 567 890',
    address: '123 Market St',
    city: 'New York',
    country: 'USA',
  };

  const createdOrder = marketplaceStore.createOrder({
    items: orderData.items || [],
    subtotal: orderData.subtotal || 0,
    shipping: orderData.shipping || 0,
    tax: orderData.tax || 0,
    total: orderData.total || 0,
    paymentMethod: orderData.paymentMethod || 'Wallet Balance',
    customer
  });

  return createdOrder;
}

// Product upload mutations
export async function createNewProduct(productData: Partial<Product>): Promise<Product & { success: boolean; product: Product }> {
  const newProduct = marketplaceStore.addProduct(productData);

  return {
    ...newProduct,
    success: true,
    product: newProduct,
  };
}
